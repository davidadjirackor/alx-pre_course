### ALX PRE_COURSE
I'm now an ALX student. This is my first repository as a full-stack engineer

**The only commit from github interface**
